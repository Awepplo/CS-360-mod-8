import java.util.*

class gridMain {
    var strNewExercises: String = NewWorkout()

    companion object {
        const val MAX = 7

        @JvmStatic
        fun main(args: Array<String>) {
            val `in` = Scanner(System.`in`)
            val dAll = DoubleArray(MAX)
            val strDay = arrayOfNulls<String>(MAX)
            val strFinalCal = arrayOfNulls<String>(MAX)
            var strExerciseCode = ""
            var strName = ""
            var strSport = ""
            val strName1 = ""
            var strExerciseName = ""
            val strExerciseName1 = ""

            // Declaration
            val strTemp = ""
            val in1 = Scanner(System.`in`)
            var dWeight = 0.0
            var dHeight = 0.0
            var dBMI = 0.0
            val strGender: String
            var strName2: String
            var strMsg: String

            // input
            strMsg = "Enter Your Name: "
            strName = JOptionPane.showInputDialog(strMsg)
            print("Welcome to Our Program!\n")
            println("Hello $strName! Tell us about yourself")
            strMsg = "Enter Gender # \n Female \n Male"
            strGender = JOptionPane.showInputDialog(strMsg)
            if (strGender == "f" || strGender == "F" || strGender == "female" || strGender == "Female" || strGender == "FEMALE") {
                println("You are Female")
            }
            if (strGender == "m" || strGender == "M" || strGender == "male" || strGender == "Male" || strGender == "MALE") {
                println("You are Male")
            }

            // process
            strMsg = JOptionPane.showInputDialog("What is you weight in pounds?")
            dWeight = strMsg.toDouble()
            println("$dWeight pounds")
            strMsg = JOptionPane.showInputDialog("What is your hight is inches?")
            dHeight = strMsg.toDouble()
            println("$dHeight inches")
            dBMI = dWeight * 703 / (dHeight * dHeight)
            System.out.printf("Your BMI is %f\n", dBMI)
            if (dBMI <= 18.5) println("Underweight, we have a little work to do!") else if (dBMI >= 18.5 && dBMI <= 24.9) println("Normal Weight, great job, lets keep it up!") else if (dBMI >= 24.9 && dBMI <= 29.9) println("Overweight, we have a little work to do!") else println("Obese, we have a lot of work to do!")

            //Inputs
            val strExercises = PrintOptions()
            strSport = GetSport()
            strExerciseCode = GetExerciseCode()
            strExerciseName = GetExercise(strExerciseCode)
            for (i in 0 until MAX) {
                strDay[i] = GetDay()
                dAll[i] = GetWorkout()
                strFinalCal[i] = GetGoal(dAll[i])
            }
            PrintHeader(strName1, strExerciseName1)
            for (i in 0 until MAX) {
                PrintDetails(dAll[i], strDay[i], strFinalCal[i])
            }
        }

        fun GetSport(): String {
            var strTemp = ""
            strTemp = JOptionPane.showInputDialog("Enter your Sport")
            println("Your sport is: \t$strTemp")
            return strTemp
        }

        fun PrintOptions(): String? {
            println("Exercise for 30 minutes!")
            println("")
            println("(CA)=Cardio")
            println("(AE)=Aerobics")
            println("(WTLFT)=Weight Lifting")
            println("(SWIM)=Swimming \n")
            return null
        }

        fun PrintHeader(strName2: String?, strMajor2: String?) {
            println("| DAY # | Calories Lost | Goal Achieved? |")
            println("|---------------------------------------------------------------|")
        }

        fun PrintDetails(dAve: Double, strName1: String?, strLetter: String?) {
            System.out.printf("|%-15s|%-15s|%-15s|\n", strName1, dAve, strLetter)
            println("|--------------------------------------------------------------")
            return
        }

        fun GetExerciseCode(): String {
            var strTemp = ""
            strTemp = JOptionPane.showInputDialog("Enter your Exercise Code")
            return strTemp
        }

        fun GetExercise(Exercise: String?): String {
            var strExerciseCode = "Enter Exercise Code"
            strExerciseCode = JOptionPane.showInputDialog(strExerciseCode)
            strExerciseCode = strExerciseCode.toUpperCase()
            when (strExerciseCode) {
                "CA" -> println("Exercise: Cardio = 413 calories\n")
                "AE" -> println("Exercise: Aerobics = 400 calories\n")
                "WTLFT" -> println("Exercise: Weight Lifting = 270 calories \n")
                "SWIM" -> println("Exercise: SWIM = 413 calories \n")
            }
            return strExerciseCode
        }

        fun Header() {
            var GetDay: String
            ()
            run {
                val strMsg = "Add another Day?"
                val strTitle = "Day #"
                var strTemp = ""
                val nReply = 0
                strTemp = ""
                strTemp = JOptionPane.showInputDialog("Enter the Day Number")
                return strTemp
            }
            var GetWorkout: Double
            ()
            run {
                val strMsg = "Add another Workout?"
                val strTitle = "Another Workout"
                var strTemp = ""
                var nNum = 0
                var nCounter = 0
                var nAccumulator = 0
                var dTot = 0.0
                val dGoal = 0.0
                var nReply = 0
                do {
                    strTemp = JOptionPane.showInputDialog("Enter Calories for each interval")
                    nNum = strTemp.toInt()
                    nAccumulator += nNum
                    nCounter++
                    nReply = JOptionPane.showConfirmDialog(null, strMsg, strTitle, JOptionPane.YES_NO_OPTION)
                } while (nReply == JOptionPane.YES_OPTION)
                dTot = nAccumulator.toDouble()
                return dTot
            }
            var GetGoal: String
            ()
            var dTot: Double
            run {
                var strGoalMsg = ""
                val strTemp: String = JOptionPane.showInputDialog("Enter Your Target Calories")
                val nNum = strTemp.toInt()
                strGoalMsg = if (dTot >= nNum) "Fantastic, goal more than achieved!" else if (dTot == nNum.toDouble()) "Great job, goal achieved!" else if (dTot <= nNum) "Keep working, almost there! " else "You have to try!!!"
                return strGoalMsg
            }
            var NewWorkout: String
            ()
            run {
                var strWorkout = ""
                val strTemp: String = JOptionPane.showInputDialog("Enter Your New Target Calories for Each Day. ")
                val nNum = strTemp.toInt()
                strWorkout = if (nNum >= 1000) "Each for 30 minutes\n Cardio, Aerobics, Swimming, Weight Lifting" else if (nNum >= 800 && nNum <= 1000) "Each for 30 minutes\n Aerobics, and Swimming" else if (nNum >= 400 && nNum <= 800) "Each for 30 minutes\n Weightlifting, and Swimming! " else "Aim Higher for your Target!!"
                println("Based on Target Calories, this is the suggested workout routine")
                println(strWorkout)
                return strWorkout
            }
        }
    }
}